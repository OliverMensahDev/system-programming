public class LinkedList<T> [
    private  head;
    private  tail;

    private  static class Node<T>{
        T value;
        Node next;
        Node previous;
    }


    add


]